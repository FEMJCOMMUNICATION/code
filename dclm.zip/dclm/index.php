<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>DCLM | Kwara choir</title>
	<link rel ="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="icon" href="DCLM.png">
</head>
<body class="body-home">

<div class="black-fill"><br />
	<div class="container">
		<nav class="navbar navbar-expand-lg bg-light" id="homeNav">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="DCLM.png" alt="DCLM" width="40"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Precis</a>
        </li>
      </ul>
      <ul class="navbar-nav me-right mb-2 mb-lg-0">
      	<li class="nav-item">
          <a class="nav-link" href="login.php"><b>Login</b></a>
        </li>
      </ul>

    </div>
  </div>
</nav>
	<section class="welcome-text d-flex justify-content-center align-items-center flex-column">
		<img src="DCLM.png">
		<h4>Welcome to DCLM Kwara Choir</h4>
		<p>This platform is for all Kwara state choir members.</p>
	</section>	
	<section id="about" class="welcome-text d-flex justify-content-center align-items-center flex-column">
		<div class="card mb-3 card-1" style="max-width: 540px;">
	  <div class="row g-0">
	    <div class="col-md-4">
	      <img src="DCLM.png" class="img-fluid rounded-start" alt="...">
	    </div>
	    <div class="col-md-8">
	      <div class="card-body">
	        <h5 class="card-title" align="align-items-center">About Us</h5>
	        <p class="card-text" align="align-items-center">This platform is for all Kwara state choir members.</p>
	        <p class="card-text"><small class="text-body-secondary">DCLM Kwara Choir</small>
	        </div>
	    </div>
	  </div>
	</div>
	</section>
	<section id="contact" class="welcome-text d-flex justify-content-center align-items-center flex-column">
		<form>
			<h3 align="align-items-center">Contact Us</h3>
		  <div class="mb-3">
		    <label for="exampleInputEmail1" class="form-label">Email address</label>
		    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
		    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
		  </div>
		  <div class="mb-3">
		    <label class="form-label">Name</label>
		    <input type="text" class="form-control">
		  </div>
		  <div class="mb-3">
		    <label class="form-label">Message</label>
		    <textarea class="form-control" rows="4"></textarea>
		  </div>
		  <!-- <div class="mb-3 form-check">
		    <input type="checkbox" class="form-check-input" id="exampleCheck1">
		    <label class="form-check-label" for="exampleCheck1">Check me out</label> 
		  </div> -->
		  <button type="submit" class="btn btn-primary">Send</button>
		</form>
	</section>
	<div class="text-center text-light">
		<!-- <h5 align="center"> -->Copyright &copy; 2023 DCLM Kwara Choir. All right reserved.<!-- </h5> -->
	</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>