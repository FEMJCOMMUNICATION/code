<?php 
session_start();
if (isset($_SESSION['admin_id']) && isset($_SESSION['role'])) {

	if ($_SESSION['role'] == 'Admin') {
	
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home | Kwara choir</title>
	<link rel ="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="icon" href="../DCLM.png">
</head>
<body>
<h1>Welcome Mr FEMJ</h1>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php 

}else {
	header("Location: ../login.php");
	exit;
} 
}else {
	header("Location: ../login.php");
	exit;
} 


?>